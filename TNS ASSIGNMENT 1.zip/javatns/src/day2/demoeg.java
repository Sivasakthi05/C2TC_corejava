package day2;

public class demoeg {
	public static void main(String[] args) {
		
		demo c1=new demo();
		demo c2=new demo();
		demo c3=new demo();
		 
		c1.setName("sakthi");
		c1.setAge("20");
		c1.setCity("panruti");
		
		c2.setName("siva");
		c2.setAge("12");
		c2.setCity("villupuram");
		
		c3.setName("kaviya");
		c3.setAge("21");
		c3.setCity("chennai");
		
		System.out.println("name:"+c1.getName()+"age"+c1.getAge()+"city"+c1.getCity());
		System.out.println("name:"+c2.getName()+"age"+c2.getAge()+"city"+c2.getCity());
		System.out.println("name:"+c3.getName()+"age"+c3.getAge()+"city"+c3.getCity());
		
		
	}

}
