package day2;

public class demofile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
