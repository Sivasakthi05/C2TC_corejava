package day2;
public class demo{
	 private String Name;
	 private int Age;
	 private String City;
	 public String getName() {
		 return Name;
	 }
	 public void setName(String name) {
		 Name = name;
	}
	 public int getAge() {
		 return Age;
	 }
	 public void setAge(int age) {
         Age = age;
	 }
	 public String getCity() {
		 return City;
	 }
	 public void setCity(String city) {
		 City = city;
	 }
       
         
}