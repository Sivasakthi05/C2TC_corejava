package day1;
import java.util.Scanner;
public class userip {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan= new Scanner(System.in);
		System.out.println("enter ur name:");
		String name=scan.nextLine();
		System.out.println("enter ur roll number:");
		int rollnumber =scan.nextInt();
		System.out.println("enter chara:");
		char ap=scan.next().charAt(0);
		System.out.println("enter pertcage:");
		float sd = scan.nextFloat();
		// use this comment af int; scan.nextLine());
System.out.println(name);
System.out.println(rollnumber);
System.out.println(ap);
System.out.println(sd+"%");

	}

}
