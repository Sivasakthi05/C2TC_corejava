package day3;

public class rectangle {
	float width;
	private float height;
     public Rectangle() {
    	 this.width=5.0f;
    	 this.height=2.0f;
    	 }
     piblic Rectangle(float width,float height) {
    	 this.width=width;
    	 this.height=height;
     }
     @override
     void calArea() {
    	 area=width*height;
     }

}
